--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE trab_individual;
--
-- Name: trab_individual; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE trab_individual WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE trab_individual OWNER TO postgres;

\connect trab_individual

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: habilidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.habilidade (
    hab_id integer NOT NULL,
    hab_nome character varying(50) NOT NULL
);


ALTER TABLE public.habilidade OWNER TO postgres;

--
-- Name: habilidade_hab_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.habilidade_hab_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.habilidade_hab_id_seq OWNER TO postgres;

--
-- Name: habilidade_hab_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.habilidade_hab_id_seq OWNED BY public.habilidade.hab_id;


--
-- Name: residente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.residente (
    resid_id integer NOT NULL,
    resid_nome character varying(50) NOT NULL,
    resid_email character varying(50) NOT NULL,
    resid_matricula character varying(50) NOT NULL
);


ALTER TABLE public.residente OWNER TO postgres;

--
-- Name: residente_resid_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.residente_resid_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.residente_resid_id_seq OWNER TO postgres;

--
-- Name: residente_resid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.residente_resid_id_seq OWNED BY public.residente.resid_id;


--
-- Name: residenthabilidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.residenthabilidade (
    resid_id integer NOT NULL,
    hab_id integer NOT NULL
);


ALTER TABLE public.residenthabilidade OWNER TO postgres;

--
-- Name: residenthabilidade_hab_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.residenthabilidade_hab_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.residenthabilidade_hab_id_seq OWNER TO postgres;

--
-- Name: residenthabilidade_hab_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.residenthabilidade_hab_id_seq OWNED BY public.residenthabilidade.hab_id;


--
-- Name: residenthabilidade_resid_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.residenthabilidade_resid_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.residenthabilidade_resid_id_seq OWNER TO postgres;

--
-- Name: residenthabilidade_resid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.residenthabilidade_resid_id_seq OWNED BY public.residenthabilidade.resid_id;


--
-- Name: habilidade hab_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.habilidade ALTER COLUMN hab_id SET DEFAULT nextval('public.habilidade_hab_id_seq'::regclass);


--
-- Name: residente resid_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residente ALTER COLUMN resid_id SET DEFAULT nextval('public.residente_resid_id_seq'::regclass);


--
-- Name: residenthabilidade resid_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residenthabilidade ALTER COLUMN resid_id SET DEFAULT nextval('public.residenthabilidade_resid_id_seq'::regclass);


--
-- Name: residenthabilidade hab_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residenthabilidade ALTER COLUMN hab_id SET DEFAULT nextval('public.residenthabilidade_hab_id_seq'::regclass);


--
-- Data for Name: habilidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3341.dat

--
-- Data for Name: residente; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3339.dat

--
-- Data for Name: residenthabilidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3344.dat

--
-- Name: habilidade_hab_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.habilidade_hab_id_seq', 1, false);


--
-- Name: residente_resid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.residente_resid_id_seq', 1, false);


--
-- Name: residenthabilidade_hab_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.residenthabilidade_hab_id_seq', 1, false);


--
-- Name: residenthabilidade_resid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.residenthabilidade_resid_id_seq', 1, false);


--
-- Name: habilidade habilidade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.habilidade
    ADD CONSTRAINT habilidade_pkey PRIMARY KEY (hab_id);


--
-- Name: residente residente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residente
    ADD CONSTRAINT residente_pkey PRIMARY KEY (resid_id);


--
-- Name: residenthabilidade residenthabilidade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residenthabilidade
    ADD CONSTRAINT residenthabilidade_pkey PRIMARY KEY (resid_id, hab_id);


--
-- Name: residenthabilidade residenthabilidade_hab_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residenthabilidade
    ADD CONSTRAINT residenthabilidade_hab_id_fkey FOREIGN KEY (hab_id) REFERENCES public.habilidade(hab_id);


--
-- Name: residenthabilidade residenthabilidade_resid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residenthabilidade
    ADD CONSTRAINT residenthabilidade_resid_id_fkey FOREIGN KEY (resid_id) REFERENCES public.residente(resid_id);


--
-- PostgreSQL database dump complete
--

